# Eesha E-Commerce Platform - Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Jumia's vibrant e-commerce aesthetic combined with modern e-commerce leaders (Shopify, Amazon) to create an engaging, conversion-focused platform.

## Core Design Principles
1. **Visual Commerce First**: Product imagery drives the experience
2. **Trust & Clarity**: Clear pricing, authentic product presentation
3. **Seamless Discovery**: Easy browsing and AI-assisted shopping
4. **Dual-Purpose Design**: Equally powerful for buyers and sellers

## Color Palette

### Light Mode
- **Primary Orange**: 25 95% 55% (Jumia-inspired energetic orange)
- **Secondary Deep Blue**: 220 40% 25% (trust and stability)
- **Success Green**: 145 70% 45% (purchase confirmations)
- **Background**: 0 0% 98% (clean white base)
- **Surface Cards**: 0 0% 100% (pure white cards)
- **Text Primary**: 220 20% 15%
- **Text Secondary**: 220 15% 45%

### Dark Mode
- **Primary Orange**: 25 90% 60% (slightly brighter for contrast)
- **Secondary Deep Blue**: 220 35% 35%
- **Success Green**: 145 65% 50%
- **Background**: 220 20% 10%
- **Surface Cards**: 220 18% 14%
- **Text Primary**: 0 0% 95%
- **Text Secondary**: 0 0% 70%

## Typography
- **Primary Font**: 'Inter' or 'Poppins' (Google Fonts) - modern, clean, excellent for e-commerce
- **Headings**: 600-700 weight, sizes from text-2xl to text-5xl
- **Body Text**: 400 weight, text-base (16px)
- **Product Prices**: 700 weight, prominent sizing (text-xl to text-3xl)
- **Labels/Meta**: 500 weight, text-sm

## Layout System
**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16, 20 (p-2, m-4, gap-6, py-8, etc.)

### Homepage Layout
- **Top Navigation Bar**: Sticky header with logo, search bar, category dropdown, cart icon, user profile (h-16)
- **Hero Banner**: 600px height slider showcasing featured deals/promotions with CTA buttons
- **Category Pills**: Horizontal scrollable category navigation (py-4)
- **Product Grid**: 6 columns on desktop (lg:grid-cols-6), 4 on tablet (md:grid-cols-4), 2 on mobile (grid-cols-2)
- **Section Spacing**: py-12 between major sections

### Dashboard Layouts
- **Sidebar Navigation**: 280px fixed width on desktop, collapsible on mobile
- **Main Content Area**: Flexible width with max-w-7xl container
- **Card-Based Interface**: Elevated cards (shadow-md) with 8px border-radius for all content blocks

## Component Library

### Navigation
- **Top Header**: Logo left, search center (flex-1 max-w-2xl), icons right (cart, notifications, profile)
- **Category Menu**: Mega dropdown with category images and subcategories
- **Breadcrumbs**: Show navigation path on product pages (text-sm with chevron separators)

### Product Cards (Homepage & Buyer Dashboard)
- **Card Structure**: Image top (aspect-ratio-square), content padding p-4
- **Product Image**: Object-cover with hover zoom effect (scale-105 transition)
- **Price Display**: Large bold price with strikethrough original price if discounted
- **Quick Actions**: Heart icon (wishlist) absolute top-right, "Add to Cart" button on hover
- **Rating Stars**: 5-star display with review count (text-sm text-gray-500)

### Authentication Pages
- **Layout**: Split screen - Left side brand imagery/value proposition (40%), Right side form (60%)
- **Form Cards**: Centered max-w-md with shadow-xl and p-8
- **Social Login**: Google/Facebook buttons with icon + text
- **Input Fields**: Full width with floating labels, border-2 focus states

### Seller Dashboard Components
- **Product Upload Form**: Multi-step wizard (Product Info → Images → Pricing → Preview)
- **Image Upload**: Drag-and-drop zone with preview thumbnails (150x150px grid)
- **Product Table**: Sortable columns (Product, Category, Price, Stock, Status, Actions)
- **Analytics Cards**: 4-column grid showing sales, revenue, products, orders with icon + number + percentage change

### Buyer Dashboard Components
- **Filter Sidebar**: Categories (expandable tree), Price range slider, Rating filter, Brand checkboxes
- **Sort Dropdown**: Price (low-high, high-low), Newest, Popular, Rating
- **View Toggle**: Grid/List view switcher
- **Pagination**: Number buttons + prev/next arrows (max 7 visible pages)

### AI Shopping Assistant
- **Chat Interface**: Fixed bottom-right bubble (60px), expands to 400px wide × 600px tall card
- **Message Bubbles**: User messages (primary orange, right-aligned), AI responses (gray, left-aligned)
- **Quick Suggestions**: Pill buttons below input for common queries ("Show me laptops under $500")
- **Product Recommendations**: Inline mini product cards within chat (image + title + price + "View" button)
- **Input Area**: Text input with microphone icon and send button, auto-focus on open

### Shopping Cart & Checkout
- **Cart Drawer**: Slide-in from right (400px width) with product thumbnails + quantity controls
- **Quantity Controls**: - button, number display, + button (inline-flex)
- **Summary Section**: Subtotal, Shipping, Tax breakdown, Total (bold text-2xl)
- **Checkout Button**: Full width, sticky bottom with primary orange background

## Interactions & Animations
- **Product Card Hover**: Subtle lift (translateY(-4px)) + shadow-lg transition
- **Image Loading**: Skeleton shimmer effect while loading
- **Add to Cart**: Success toast notification top-right with checkmark icon
- **Page Transitions**: Fade in content (opacity 0 to 1, 200ms)
- **Modal Overlays**: Backdrop blur (backdrop-blur-sm) + fade in animation

## Images

### Homepage Hero
- **Quantity**: 3-5 rotating banner images (auto-play carousel)
- **Content**: Promotional banners showing featured products, seasonal sales, new arrivals
- **Dimensions**: 1920×600px (desktop), 768×400px (mobile)
- **Placement**: Full-width at top of homepage below navigation

### Product Images
- **Thumbnail Grid**: Multiple angles per product (4-6 images)
- **Main Image**: Large zoomable product photo
- **Placeholder**: Gray background with shopping bag icon for missing images

### Category Images
- **Mega Menu**: Small category illustrations (80×80px) beside category names
- **Banner Images**: Category-specific hero images on category pages

### Dashboard
- **Empty States**: Friendly illustrations for "No products yet" (seller) or "No orders" (buyer)
- **Onboarding**: Step-by-step guide illustrations for first-time sellers

## Accessibility & Responsive Design
- **Mobile First**: Stack all multi-column layouts to single column on mobile
- **Touch Targets**: Minimum 44×44px for all interactive elements
- **Contrast Ratios**: WCAG AA compliant (4.5:1 for text)
- **Focus States**: Visible ring-2 ring-primary with offset on all interactive elements
- **Screen Reader Labels**: aria-labels for icon-only buttons
- **Dark Mode Toggle**: Switch in user menu, respects system preference by default

## Key Screens Breakdown

**Homepage**: Hero carousel → Category pills → "Flash Sales" grid (8 products) → "Recommended for You" grid → "New Arrivals" → Footer with links

**Buyer Dashboard**: Filter sidebar (left) → Product grid (main) → AI assistant bubble (bottom-right)

**Seller Dashboard**: Stats cards (top) → Recent orders table → Quick actions (Add Product, View Analytics) → Product management table

**Product Detail**: Large image gallery (left 60%) → Product info, price, add to cart (right 40%) → Tabs (Description, Reviews, Specifications) → Related products grid

This design creates a vibrant, trustworthy e-commerce experience that balances visual appeal with functionality for both buyers and sellers.