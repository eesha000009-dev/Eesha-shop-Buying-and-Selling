// Mock product data
const products = [
    {
        id: 1,
        name: "Premium Smartphone X Pro",
        price: 899,
        originalPrice: 1199,
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400",
        category: "Electronics",
        rating: 5
    },
    {
        id: 2,
        name: "Wireless Headphones Ultra",
        price: 249,
        originalPrice: 349,
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
        category: "Audio",
        rating: 5
    },
    {
        id: 3,
        name: "Professional Laptop",
        price: 1299,
        originalPrice: null,
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
        category: "Computers",
        rating: 5
    },
    {
        id: 4,
        name: "Smart Watch Pro",
        price: 399,
        originalPrice: 499,
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400",
        category: "Wearables",
        rating: 5
    },
    {
        id: 5,
        name: "DSLR Camera Kit",
        price: 1899,
        originalPrice: 2299,
        image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
        category: "Photography",
        rating: 5
    },
    {
        id: 6,
        name: "Gaming Controller Elite",
        price: 179,
        originalPrice: 249,
        image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400",
        category: "Gaming",
        rating: 5
    }
];

// Carousel functionality
let currentSlide = 0;
const slides = document.querySelectorAll('.carousel-slide');
const indicatorsContainer = document.getElementById('carouselIndicators');

function createIndicators() {
    slides.forEach((_, index) => {
        const indicator = document.createElement('div');
        indicator.className = `indicator ${index === 0 ? 'active' : ''}`;
        indicator.addEventListener('click', () => goToSlide(index));
        indicatorsContainer.appendChild(indicator);
    });
}

function goToSlide(index) {
    slides.forEach(slide => slide.classList.remove('active'));
    document.querySelectorAll('.indicator').forEach(ind => ind.classList.remove('active'));
    
    currentSlide = index;
    slides[currentSlide].classList.add('active');
    document.querySelectorAll('.indicator')[currentSlide].classList.add('active');
}

function nextSlide() {
    goToSlide((currentSlide + 1) % slides.length);
}

function prevSlide() {
    goToSlide((currentSlide - 1 + slides.length) % slides.length);
}

document.getElementById('nextSlide').addEventListener('click', nextSlide);
document.getElementById('prevSlide').addEventListener('click', prevSlide);

// Auto-advance carousel
setInterval(nextSlide, 5000);
createIndicators();

// Render products
function renderProducts(productsToRender = products) {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = productsToRender.map(product => {
        const discount = product.originalPrice 
            ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
            : 0;

        return `
            <div class="product-card" onclick="handleProductClick(${product.id})">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    <button class="wishlist-btn" onclick="event.stopPropagation(); toggleWishlist(${product.id})">❤️</button>
                    ${discount > 0 ? `<div class="discount-badge">-${discount}%</div>` : ''}
                </div>
                <div class="product-info">
                    <span class="product-category">${product.category}</span>
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-rating">
                        ${'⭐'.repeat(product.rating)}
                        <span>(${product.rating})</span>
                    </div>
                    <div class="product-price">
                        <span class="price">$${product.price}</span>
                        ${product.originalPrice ? `<span class="original-price">$${product.originalPrice}</span>` : ''}
                    </div>
                    <button class="add-to-cart-btn" onclick="event.stopPropagation(); addToCart(${product.id})">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function handleProductClick(productId) {
    // Show auth modal if not logged in
    const isLoggedIn = localStorage.getItem('user');
    if (!isLoggedIn) {
        document.getElementById('authModal').classList.add('active');
    } else {
        window.location.href = `/product.html?id=${productId}`;
    }
}

function toggleWishlist(productId) {
    console.log('Wishlist toggled for product:', productId);
}

function addToCart(productId) {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find(item => item.id === productId);
    
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ id: productId, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert('Product added to cart!');
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = count;
}

// Category filter
document.getElementById('categoryPills').addEventListener('click', (e) => {
    if (e.target.classList.contains('category-pill')) {
        document.querySelectorAll('.category-pill').forEach(pill => {
            pill.classList.remove('active');
        });
        e.target.classList.add('active');
        
        const category = e.target.dataset.category;
        if (category === 'all') {
            renderProducts(products);
        } else {
            const filtered = products.filter(p => p.category === category);
            renderProducts(filtered);
        }
    }
});

// Auth Modal
const authModal = document.getElementById('authModal');
const loginBtn = document.getElementById('loginBtn');
const closeModal = document.getElementById('closeModal');

loginBtn.addEventListener('click', () => {
    authModal.classList.add('active');
});

closeModal.addEventListener('click', () => {
    authModal.classList.remove('active');
});

// Tab switching
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${tab}Tab`).classList.remove('hidden');
    });
});

// Login form
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Mock login
    localStorage.setItem('user', JSON.stringify({ email, userType: 'buyer' }));
    authModal.classList.remove('active');
    window.location.href = '/dashboard.html';
});

// Signup form
document.getElementById('signupForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('signupUsername').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const userType = document.querySelector('input[name="userType"]:checked').value;
    
    // Mock signup
    localStorage.setItem('user', JSON.stringify({ username, email, userType }));
    authModal.classList.remove('active');
    window.location.href = '/dashboard.html';
});

// AI Assistant
const aiToggle = document.getElementById('aiToggle');
const aiChat = document.getElementById('aiChat');
const aiClose = document.getElementById('aiClose');
const aiInput = document.getElementById('aiInput');
const aiSend = document.getElementById('aiSend');
const aiMessages = document.getElementById('aiMessages');

aiToggle.addEventListener('click', () => {
    aiChat.classList.remove('hidden');
    aiToggle.style.display = 'none';
});

aiClose.addEventListener('click', () => {
    aiChat.classList.add('hidden');
    aiToggle.style.display = 'block';
});

function addAIMessage(message, role) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${role}`;
    messageDiv.textContent = message;
    aiMessages.appendChild(messageDiv);
    aiMessages.scrollTop = aiMessages.scrollHeight;
}

aiSend.addEventListener('click', () => {
    const message = aiInput.value.trim();
    if (message) {
        addAIMessage(message, 'user');
        aiInput.value = '';
        
        // Mock AI response
        setTimeout(() => {
            addAIMessage(`I found some great options for "${message}". Let me show you our top picks!`, 'assistant');
        }, 1000);
    }
});

aiInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        aiSend.click();
    }
});

// Suggestion pills
document.querySelectorAll('.suggestion-pill').forEach(pill => {
    pill.addEventListener('click', () => {
        aiInput.value = pill.textContent;
        aiSend.click();
    });
});

// Initialize
renderProducts();
updateCartCount();
