// Get product ID from URL
const urlParams = new URLSearchParams(window.location.search);
const productId = parseInt(urlParams.get('id'));

// Mock products
const products = [
    {
        id: 1,
        name: "Premium Smartphone X Pro",
        price: 899,
        originalPrice: 1199,
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800",
        category: "Electronics",
        rating: 5,
        description: "Experience cutting-edge technology with the Premium Smartphone X Pro. Featuring a stunning display, powerful processor, and advanced camera system."
    },
    {
        id: 2,
        name: "Wireless Headphones Ultra",
        price: 249,
        originalPrice: 349,
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800",
        category: "Audio",
        rating: 5,
        description: "Premium sound quality with active noise cancellation. Enjoy wireless freedom with 30-hour battery life."
    },
    {
        id: 3,
        name: "Professional Laptop",
        price: 1299,
        originalPrice: null,
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800",
        category: "Computers",
        rating: 5,
        description: "High-performance laptop for professionals. Powerful processor, stunning display, and all-day battery life."
    }
];

// Find product
const product = products.find(p => p.id === productId);

if (product) {
    // Update page content
    document.getElementById('mainImage').src = product.image;
    document.getElementById('mainImage').alt = product.name;
    document.getElementById('productCategory').textContent = product.category;
    document.getElementById('productName').textContent = product.name;
    document.getElementById('productRating').innerHTML = '⭐'.repeat(product.rating);
    document.getElementById('productPrice').textContent = `$${product.price}`;
    document.getElementById('productDescription').textContent = product.description;

    if (product.originalPrice) {
        const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
        document.getElementById('originalPrice').textContent = `$${product.originalPrice}`;
        document.getElementById('discountBadge').textContent = `-${discount}%`;
    }
} else {
    document.querySelector('main').innerHTML = '<div style="text-align: center; padding: 4rem;"><h2>Product not found</h2><a href="/" class="btn btn-primary">Back to Home</a></div>';
}

// Quantity controls
let quantity = 1;

function increaseQty() {
    quantity++;
    document.getElementById('quantity').textContent = quantity;
}

function decreaseQty() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('quantity').textContent = quantity;
    }
}

function addToCart() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find(item => item.id === productId);
    
    if (existing) {
        existing.quantity += quantity;
    } else {
        cart.push({ id: productId, quantity: quantity });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert('Added to cart!');
}

function toggleWishlist() {
    alert('Added to wishlist!');
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = count;
}

// AI Assistant
const aiToggle = document.getElementById('aiToggle');
const aiChat = document.getElementById('aiChat');
const aiClose = document.getElementById('aiClose');
const aiInput = document.getElementById('aiInput');
const aiSend = document.getElementById('aiSend');
const aiMessages = document.getElementById('aiMessages');

aiToggle.addEventListener('click', () => {
    aiChat.classList.remove('hidden');
    aiToggle.style.display = 'none';
});

aiClose.addEventListener('click', () => {
    aiChat.classList.add('hidden');
    aiToggle.style.display = 'block';
});

function addAIMessage(message, role) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${role}`;
    messageDiv.textContent = message;
    aiMessages.appendChild(messageDiv);
    aiMessages.scrollTop = aiMessages.scrollHeight;
}

// Add initial message
addAIMessage("Hi! Need help finding similar products?", 'assistant');

aiSend.addEventListener('click', () => {
    const message = aiInput.value.trim();
    if (message) {
        addAIMessage(message, 'user');
        aiInput.value = '';
        
        setTimeout(() => {
            addAIMessage(`I can help you find products similar to "${product.name}". Let me show you some options!`, 'assistant');
        }, 1000);
    }
});

// Initialize
updateCartCount();
