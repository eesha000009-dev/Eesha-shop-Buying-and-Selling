// Check if user is logged in
const user = JSON.parse(localStorage.getItem('user') || 'null');
if (!user) {
    window.location.href = '/';
}

// Mock products data
const products = [
    {
        id: 1,
        name: "Premium Smartphone X Pro",
        price: 899,
        originalPrice: 1199,
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400",
        category: "Electronics",
        rating: 5,
        sellerId: "seller1"
    },
    {
        id: 2,
        name: "Wireless Headphones Ultra",
        price: 249,
        originalPrice: 349,
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
        category: "Audio",
        rating: 5,
        sellerId: "seller1"
    },
    {
        id: 3,
        name: "Professional Laptop",
        price: 1299,
        originalPrice: null,
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
        category: "Computers",
        rating: 5,
        sellerId: "seller2"
    }
];

// Tab switching
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${tab}Tab`).classList.remove('hidden');
    });
});

// Buyer Dashboard
function renderBuyerProducts(productsToRender = products) {
    const grid = document.getElementById('buyerProducts');
    grid.innerHTML = productsToRender.map(product => {
        const discount = product.originalPrice 
            ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
            : 0;

        return `
            <div class="product-card">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    ${discount > 0 ? `<div class="discount-badge">-${discount}%</div>` : ''}
                </div>
                <div class="product-info">
                    <span class="product-category">${product.category}</span>
                    <h3 class="product-name">${product.name}</h3>
                    <div class="product-rating">
                        ${'⭐'.repeat(product.rating)}
                    </div>
                    <div class="product-price">
                        <span class="price">$${product.price}</span>
                        ${product.originalPrice ? `<span class="original-price">$${product.originalPrice}</span>` : ''}
                    </div>
                    <button class="add-to-cart-btn" onclick="addToCart(${product.id})">
                        🛒 Add to Cart
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// Filters
const filterBtn = document.getElementById('filterBtn');
const filtersSidebar = document.getElementById('filtersSidebar');

filterBtn.addEventListener('click', () => {
    filtersSidebar.classList.toggle('hidden');
});

document.getElementById('priceRange').addEventListener('input', (e) => {
    document.getElementById('priceValue').textContent = e.target.value;
    applyFilters();
});

document.getElementById('categoryFilter').addEventListener('change', applyFilters);

function applyFilters() {
    const maxPrice = parseInt(document.getElementById('priceRange').value);
    const category = document.getElementById('categoryFilter').value;
    
    let filtered = products.filter(p => p.price <= maxPrice);
    if (category !== 'all') {
        filtered = filtered.filter(p => p.category === category);
    }
    
    renderBuyerProducts(filtered);
}

// Seller Dashboard
function renderSellerProducts() {
    const container = document.getElementById('sellerProductsList');
    const sellerProducts = products.filter(p => p.sellerId === 'seller1');
    
    container.innerHTML = sellerProducts.map(product => `
        <div class="product-card">
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
            </div>
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-category">${product.category}</p>
                <div class="product-price">
                    <span class="price">$${product.price}</span>
                </div>
                <button class="btn btn-outline" onclick="editProduct(${product.id})">Edit</button>
            </div>
        </div>
    `).join('');
}

// Add Product Modal
const addProductBtn = document.getElementById('addProductBtn');
const addProductModal = document.getElementById('addProductModal');
const closeProductModal = document.getElementById('closeProductModal');
const cancelProduct = document.getElementById('cancelProduct');

addProductBtn.addEventListener('click', () => {
    addProductModal.classList.add('active');
});

closeProductModal.addEventListener('click', () => {
    addProductModal.classList.remove('active');
});

cancelProduct.addEventListener('click', () => {
    addProductModal.classList.remove('active');
});

document.getElementById('addProductForm').addEventListener('submit', (e) => {
    e.preventDefault();
    
    const newProduct = {
        id: products.length + 1,
        name: document.getElementById('productName').value,
        price: parseInt(document.getElementById('productPrice').value),
        originalPrice: document.getElementById('productOriginalPrice').value 
            ? parseInt(document.getElementById('productOriginalPrice').value) 
            : null,
        category: document.getElementById('productCategory').value,
        image: document.getElementById('productImage').value,
        rating: 5,
        sellerId: 'seller1'
    };
    
    products.push(newProduct);
    renderSellerProducts();
    addProductModal.classList.remove('active');
    e.target.reset();
    alert('Product added successfully!');
});

// Cart functions
function addToCart(productId) {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find(item => item.id === productId);
    
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ id: productId, quantity: 1 });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    alert('Product added to cart!');
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = count;
}

function editProduct(productId) {
    console.log('Edit product:', productId);
    alert('Edit functionality coming soon!');
}

// Logout
document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('user');
    window.location.href = '/';
});

// AI Assistant
const aiToggle = document.getElementById('aiToggle');
const aiChat = document.getElementById('aiChat');
const aiClose = document.getElementById('aiClose');
const aiInput = document.getElementById('aiInput');
const aiSend = document.getElementById('aiSend');
const aiMessages = document.getElementById('aiMessages');

aiToggle.addEventListener('click', () => {
    aiChat.classList.remove('hidden');
    aiToggle.style.display = 'none';
});

aiClose.addEventListener('click', () => {
    aiChat.classList.add('hidden');
    aiToggle.style.display = 'block';
});

function addAIMessage(message, role) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-message ${role}`;
    messageDiv.textContent = message;
    aiMessages.appendChild(messageDiv);
    aiMessages.scrollTop = aiMessages.scrollHeight;
}

// Add initial message
addAIMessage("Hi! I'm your shopping assistant. Tell me what you're looking for and I'll help you find it!", 'assistant');

aiSend.addEventListener('click', () => {
    const message = aiInput.value.trim();
    if (message) {
        addAIMessage(message, 'user');
        aiInput.value = '';
        
        // Mock AI response
        setTimeout(() => {
            addAIMessage(`I found some great options for "${message}". Let me show you our top picks!`, 'assistant');
        }, 1000);
    }
});

aiInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        aiSend.click();
    }
});

// Initialize
renderBuyerProducts();
renderSellerProducts();
updateCartCount();
