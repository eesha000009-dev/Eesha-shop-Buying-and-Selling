import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve static files from client/public
  app.use(express.static(path.join(process.cwd(), "client", "public")));

  // API routes for future backend functionality
  app.get("/api/products", async (req, res) => {
    // This will be implemented with real database later
    res.json([]);
  });

  app.post("/api/products", async (req, res) => {
    // This will be implemented with real database later
    res.json({ success: true });
  });

  app.post("/api/auth/login", async (req, res) => {
    // This will be implemented with real authentication later
    res.json({ success: true });
  });

  app.post("/api/auth/signup", async (req, res) => {
    // This will be implemented with real authentication later
    res.json({ success: true });
  });

  // Serve index.html for all other routes (SPA fallback)
  app.get("*", (req, res) => {
    res.sendFile(path.join(process.cwd(), "client", "public", "index.html"));
  });

  const httpServer = createServer(app);

  return httpServer;
}
